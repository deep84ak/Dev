
const MAP = {
  EURUSD:"EURUSD=X", GBPUSD:"GBPUSD=X", EURGBP:"EURGBP=X",
  AUDUSD:"AUDUSD=X", USDJPY:"JPY=X", GBPJPY:"GBPJPY=X",
  AUDJPY:"AUDJPY=X", NZDUSD:"NZDUSD=X"
};

export default async function handler(req, res) {
  try {
    const pair = String(req.query.pair || "EURUSD").toUpperCase();
    const symbol = MAP[pair];
    if (!symbol) return res.status(400).json({error:"Unsupported pair"});

    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=1m&range=1d`;
    const r = await fetch(url, {headers:{"User-Agent":"Mozilla/5.0"}});
    if (!r.ok) return res.status(502).json({error:`Feed error ${r.status}`});

    const j = await r.json();
    const x = j?.chart?.result?.[0];
    const q = x?.indicators?.quote?.[0];
    const ts = x?.timestamp || [];
    if (!q || !ts.length) return res.status(502).json({error:"No candles"});

    const candles = [];
    for (let i=0;i<ts.length;i++) {
      const o=q.open?.[i], h=q.high?.[i], l=q.low?.[i], c=q.close?.[i];
      if ([o,h,l,c].every(Number.isFinite)) candles.push({t:ts[i]*1000,o,h,l,c});
    }
    res.setHeader("Cache-Control","no-store");
    res.status(200).json({pair,candles:candles.slice(-220),fetchedAt:Date.now()});
  } catch(e) {
    res.status(500).json({error:e.message || "Server error"});
  }
}
